#ifndef AUTH_H
#define AUTH_H

#include <stdbool.h>
#include "models.h"

bool isLoginUnique(AppState* state, const char* login);
void showLoginScreen(AppState* state);

#endif