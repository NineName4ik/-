#include <stdio.h>
#include <stdlib.h>
#include "utils.h"

void clearInputBuffer() {
    while (getchar() != '\n');
}

void pressAnyKeyToContinue() {
    printf("\nНажмите Enter для продолжения...");
    getchar();
}

void clearScreen() {
#ifdef _WIN32
    system("cls");
#else
    system("clear");
#endif
}

bool isPositive(int value) {
    return value > 0;
}