#include <stdio.h>
#include "models.h"
#include "utils.h"
#include "database.h"
#include "auth.h"
#include "drugs_manager.h"
#include <locale.h>

#ifdef _WIN32
#include <windows.h>
#endif

void showPharmacistMenu(AppState* state) {
    int choice;
    do {
        clearScreen();
        printf("=== МЕНЮ ФАРМАЦЕВТА ===\n\n");
        printf("1. Просмотр всех препаратов\n");
        printf("2. Поиск препарата\n");
        printf("3. Сортировка по алфавиту\n");
        printf("0. Выход из аккаунта\n\n");
        printf("Ваш выбор: ");
        scanf("%d", &choice);
        clearInputBuffer();

        switch (choice) {
            case 1: displayDrugs(state); break;
            case 2: searchDrugs(state); break;
            case 3: sortDrugs(state); break;
            case 0: state->currentUserId = -1; break;
        }
    } while (choice != 0);
}

void showAdminMenu(AppState* state) {
    int choice;
    do {
        clearScreen();
        printf("=== МЕНЮ АДМИНИСТРАТОРА ===\n\n");
        printf("1. Просмотр всех препаратов\n");
        printf("2. Добавить препарат\n");
        printf("3. Редактировать препарат\n");
        printf("4. Удалить препарат\n");
        printf("5. Поиск препарата\n");
        printf("6. Сортировка по алфавиту\n");
        printf("0. Выход из аккаунта\n\n");
        printf("Ваш выбор: ");
        scanf("%d", &choice);
        clearInputBuffer();

        switch (choice) {
            case 1: displayDrugs(state); break;
            case 2: addDrug(state); break;
            case 3: editDrug(state); break;
            case 4: deleteDrug(state); break;
            case 5: searchDrugs(state); break;
            case 6: sortDrugs(state); break;
            case 0: state->currentUserId = -1; break;
        }
    } while (choice != 0);
}

int main() {
    // 1. Устанавливаем локаль системы по умолчанию
    setlocale(LC_ALL, ".UTF8"); 

    // 2. Принудительно включаем UTF-8 для консоли Windows
#ifdef _WIN32
    SetConsoleCP(CP_UTF8);
    SetConsoleOutputCP(CP_UTF8);
#endif

    AppState state;

    // 3. Инициализация базы данных
    if (!initializeData(&state)) {
        printf("Критическая ошибка: не удалось инициализировать данные.\n");
        return 1;
    }

    // 4. Главный цикл программы
    while (1) {
        showLoginScreen(&state);

        if (state.currentUserId == -1) break;

        if (state.currentUserRole == ROLE_ADMIN) {
            showAdminMenu(&state);
        } else {
            showPharmacistMenu(&state);
        }
    }

    return 0;
}