#ifndef DRUGS_MANAGER_H
#define DRUGS_MANAGER_H

#include "models.h"

void displayDrugs(AppState* state);
void addDrug(AppState* state);
void editDrug(AppState* state);
void deleteDrug(AppState* state);
void sortDrugs(AppState* state);
void searchDrugs(AppState* state);

#endif