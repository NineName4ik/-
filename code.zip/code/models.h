#ifndef MODELS_H
#define MODELS_H

#include <stdbool.h>

#define MAX_USERS 10
#define MAX_DRUGS 100
#define MAX_NAME_LEN 50
#define MAX_CATEGORY_LEN 30
#define MAX_LOGIN_LEN 15
#define MAX_PASS_LEN 15

typedef enum {
    ROLE_ADMIN = 1,
    ROLE_PHARMACIST = 2
} UserRole;

typedef struct {
    char login[MAX_LOGIN_LEN];
    char password[MAX_PASS_LEN];
    UserRole role;
} User;

typedef struct {
    int id;
    char name[MAX_NAME_LEN];
    char category[MAX_CATEGORY_LEN];
    int quantity;
    float price;
} Drug;

typedef struct {
    User users[MAX_USERS];
    Drug drugs[MAX_DRUGS];
    int numOfUsers;
    int numOfDrugs;
    int currentUserId;
    UserRole currentUserRole;
} AppState;

#endif