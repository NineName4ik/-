#ifndef DATABASE_H
#define DATABASE_H

#include <stdbool.h>
#include "models.h"

bool saveUsers(AppState* state);
bool saveDrugs(AppState* state);
bool initializeData(AppState* state);

#endif