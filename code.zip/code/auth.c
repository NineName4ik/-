#include <stdio.h>
#include <string.h>
#include "auth.h"
#include "utils.h"

bool isLoginUnique(AppState* state, const char* login) {
    for (int i = 0; i < state->numOfUsers; i++) {
        if (strcmp(state->users[i].login, login) == 0) return false;
    }
    return true;
}

bool verifyCredentials(AppState* state, const char* login, const char* pass) {
    for (int i = 0; i < state->numOfUsers; i++) {
        if (strcmp(state->users[i].login, login) == 0 && strcmp(state->users[i].password, pass) == 0) {
            state->currentUserId = i;
            state->currentUserRole = state->users[i].role;
            return true;
        }
    }
    return false;
}

void showLoginScreen(AppState* state) {
    char login[MAX_LOGIN_LEN];
    char password[MAX_PASS_LEN];

    while (state->currentUserId == -1) {
        clearScreen();
        printf("=== БАЗА ДАННЫХ ЛЕКАРСТВЕННЫХ СРЕДСТВ ===\n");
        printf("Авторизация\n\n");
        printf("Логин: ");
        scanf("%14s", login);
        printf("Пароль: ");
        scanf("%14s", password);
        clearInputBuffer();

        if (verifyCredentials(state, login, password)) {
            printf("\nУспешный вход! Добро пожаловать, %s.\n", login);
            pressAnyKeyToContinue();
        } else {
            printf("\nНеверный логин или пароль.\n");
            pressAnyKeyToContinue();
        }
    }
}