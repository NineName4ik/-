#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "drugs_manager.h"
#include "utils.h"
#include "database.h"


void displayDrugs(AppState* state) {
    clearScreen();
    if (state->numOfDrugs == 0) {
        printf("База данных пуста.\n");
        pressAnyKeyToContinue();
        return;
    }
    printf("=== СПИСОК ЛЕКАРСТВ ===\n\n");
    printf("%-5s | %-20s | %-15s | %-8s | %-8s\n", "ID", "Название", "Категория", "Кол-во", "Цена");
    printf("------------------------------------------------------------------\n");
    for (int i = 0; i < state->numOfDrugs; i++) {
        printf("%-5d | %-20s | %-15s | %-8d | %-8.2f\n", 
            state->drugs[i].id, state->drugs[i].name, 
            state->drugs[i].category, state->drugs[i].quantity, state->drugs[i].price);
    }
    pressAnyKeyToContinue();
}

void addDrug(AppState* state) {
    if (state->numOfDrugs >= MAX_DRUGS) {
        printf("База данных заполнена!\n");
        pressAnyKeyToContinue();
        return;
    }

    Drug newDrug;
    do {
        printf("Введите ID препарата: ");
        scanf("%d", &newDrug.id);
    } while (!isPositive(newDrug.id));
    clearInputBuffer();

    printf("Название препарата: ");
    fgets(newDrug.name, MAX_NAME_LEN, stdin);
    newDrug.name[strcspn(newDrug.name, "\n")] = 0;

    printf("Категория (например, Антибиотик): ");
    fgets(newDrug.category, MAX_CATEGORY_LEN, stdin);
    newDrug.category[strcspn(newDrug.category, "\n")] = 0;

    printf("Количество на складе: ");
    scanf("%d", &newDrug.quantity);
    printf("Цена: ");
    scanf("%f", &newDrug.price);
    clearInputBuffer();

    state->drugs[state->numOfDrugs++] = newDrug;
    
    if (saveDrugs(state)) {
        printf("\nПрепарат успешно добавлен!\n");
    } else {
        printf("\nОшибка сохранения.\n");
    }
    pressAnyKeyToContinue();
}

void editDrug(AppState* state) {
    if (state->numOfDrugs == 0) {
        printf("База данных пуста.\n");
        pressAnyKeyToContinue();
        return;
    }
    
    int id;
    printf("Введите ID препарата для редактирования (0 для отмены): ");
    scanf("%d", &id);
    clearInputBuffer();

    if (id == 0) return;

    // Ищем индекс препарата в массиве
    int index = -1;
    for (int i = 0; i < state->numOfDrugs; i++) {
        if (state->drugs[i].id == id) {
            index = i;
            break;
        }
    }

    if (index == -1) {
        printf("Препарат с ID %d не найден.\n", id);
        pressAnyKeyToContinue();
        return;
    }

    //  удобный указатель на найденное лекарство
    Drug* drug = &state->drugs[index];

    printf("\n--- Редактирование: %s (ID: %d) ---\n", drug->name, drug->id);

    char newName[MAX_NAME_LEN];
    printf("Новое название (текущее: '%s', нажмите Enter чтобы оставить): ", drug->name);
    fgets(newName, MAX_NAME_LEN, stdin);
    if (newName[0] != '\n') { // Если ввели что-то кроме простого Enter
        newName[strcspn(newName, "\n")] = 0;
        strcpy(drug->name, newName);
    }

    char newCategory[MAX_CATEGORY_LEN];
    printf("Новая категория (текущая: '%s', нажмите Enter чтобы оставить): ", drug->category);
    fgets(newCategory, MAX_CATEGORY_LEN, stdin);
    if (newCategory[0] != '\n') {
        newCategory[strcspn(newCategory, "\n")] = 0;
        strcpy(drug->category, newCategory);
    }

    int newQuantity;
    printf("Новое кол-во на складе (текущее: %d, введите -1 чтобы оставить): ", drug->quantity);
    scanf("%d", &newQuantity);
    if (newQuantity != -1 && newQuantity >= 0) {
        drug->quantity = newQuantity;
    }

    float newPrice;
    printf("Новая цена (текущая: %.2f, введите -1 чтобы оставить): ", drug->price);
    scanf("%f", &newPrice);
    if (newPrice != -1 && newPrice >= 0) {
        drug->price = newPrice;
    }
    clearInputBuffer();

    // сохраняем изменения на жесткий диск
    if (saveDrugs(state)) {
        printf("\nДанные препарата успешно обновлены!\n");
    } else {
        printf("\nОшибка сохранения в файл.\n");
    }
    pressAnyKeyToContinue();
}

void deleteDrug(AppState* state) {
    if (state->numOfDrugs == 0) {
        printf("База данных пуста.\n");
        pressAnyKeyToContinue();
        return;
    }
    
    int id;
    printf("Введите ID препарата для удаления: ");
    scanf("%d", &id);
    clearInputBuffer();

    for (int i = 0; i < state->numOfDrugs; i++) {
        if (state->drugs[i].id == id) {
            state->drugs[i] = state->drugs[state->numOfDrugs - 1];
            state->numOfDrugs--;
            saveDrugs(state);
            printf("Препарат с ID %d удален.\n", id);
            pressAnyKeyToContinue();
            return;
        }
    }
    printf("Препарат не найден.\n");
    pressAnyKeyToContinue();
}

int compareDrugsByName(const void* a, const void* b) {
    return strcmp(((Drug*)a)->name, ((Drug*)b)->name);
}

void sortDrugs(AppState* state) {
    if (state->numOfDrugs == 0) return;
    qsort(state->drugs, state->numOfDrugs, sizeof(Drug), compareDrugsByName);
    saveDrugs(state);
    printf("Препараты отсортированы по названию (А-Я).\n");
    pressAnyKeyToContinue();
}

void searchDrugs(AppState* state) {
    char target[MAX_NAME_LEN];
    printf("Введите часть названия для поиска: ");
    fgets(target, MAX_NAME_LEN, stdin);
    target[strcspn(target, "\n")] = 0;

    bool found = false;
    printf("\nРезультаты поиска:\n");
    for (int i = 0; i < state->numOfDrugs; i++) {
        if (strstr(state->drugs[i].name, target) != NULL) {
            printf("ID: %d | Название: %s | Цена: %.2f\n", 
                state->drugs[i].id, state->drugs[i].name, state->drugs[i].price);
            found = true;
        }
    }
    if (!found) printf("Совпадений не найдено.\n");
    pressAnyKeyToContinue();
}