#include <stdio.h>
#include <string.h>
#include "database.h"

const char* USERS_FILE = "users.bin";
const char* DRUGS_FILE = "pharmacy.bin";

bool saveUsers(AppState* state) {
    FILE* file = fopen(USERS_FILE, "wb");
    if (!file) return false;
    fwrite(&state->numOfUsers, sizeof(int), 1, file);
    fwrite(state->users, sizeof(User), state->numOfUsers, file);
    fclose(file);
    return true;
}

bool saveDrugs(AppState* state) {
    FILE* file = fopen(DRUGS_FILE, "wb");
    if (!file) return false;
    fwrite(&state->numOfDrugs, sizeof(int), 1, file);
    fwrite(state->drugs, sizeof(Drug), state->numOfDrugs, file);
    fclose(file);
    return true;
}


void createDefaultUsers(AppState* state) {
    state->numOfUsers = 2; 

    // 1. Моя учётка
    strcpy(state->users[0].login, "qutline");
    strcpy(state->users[0].password, "12345"); 
    state->users[0].role = ROLE_ADMIN; // Полные права

    // 2. Для преподователя
    strcpy(state->users[1].login, "shamyna");
    strcpy(state->users[1].password, "12345");
    state->users[1].role = ROLE_ADMIN; // Полные права для проверки курсовой

    saveUsers(state);
}

bool initializeData(AppState* state) {
    state->numOfUsers = 0;
    state->numOfDrugs = 0;
    state->currentUserId = -1;

    FILE* uf = fopen(USERS_FILE, "rb");
    if (uf) {
        fread(&state->numOfUsers, sizeof(int), 1, uf);
        fread(state->users, sizeof(User), state->numOfUsers, uf);
        fclose(uf);
    } else {
        createDefaultUsers(state);
    }

    FILE* df = fopen(DRUGS_FILE, "rb");
    if (df) {
        fread(&state->numOfDrugs, sizeof(int), 1, df);
        fread(state->drugs, sizeof(Drug), state->numOfDrugs, df);
        fclose(df);
    }
    return true;
}