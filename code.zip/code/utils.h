#ifndef UTILS_H
#define UTILS_H

#include <stdbool.h>

void clearInputBuffer();
void pressAnyKeyToContinue();
void clearScreen();
bool isPositive(int value);

#endif